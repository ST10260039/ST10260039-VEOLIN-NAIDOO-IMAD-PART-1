package com.veolin.calculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var edtInput = findViewById<EditText>(R.id.edtInput)
        var edtInput2 = findViewById<EditText>(R.id.edtInput2)
        var edtMainAnswer = findViewById<TextView>(R.id.edtMainAnswer)


        var btnSub = findViewById<Button>(R.id.btnSub)
        btnSub.setOnClickListener {
            var Num1 : Int = edtInput.text.toString().toInt()
            var Num2 : Int = edtInput2.text.toString().toInt()
            var SubAns = Num1-Num2
            edtMainAnswer.text = String.format("$Num1"+"-"+"$Num2"+"="+"$SubAns")
        }
        var btnAdd = findViewById<Button>(R.id.btnAdd)
        btnAdd.setOnClickListener {
            var Num3 : Int = edtInput.text.toString().toInt()
            var Num4 : Int = edtInput2.text.toString().toInt()
            var AddAns = Num3+Num4
            edtMainAnswer.text = String.format("$Num3"+"+"+"$Num4"+"="+"$AddAns")

        var btnDiv = findViewById<Button>(R.id.btnDiv)
        btnDiv.setOnClickListener {
            var Num5 : Int = edtInput.text.toString().toInt()
            var Num6 : Int = edtInput2.text.toString().toInt()
            var DivAns = Num5/Num6
            edtMainAnswer.text = String.format("$Num5"+"÷"+"$Num6"+"="+"$DivAns")
        }
        var btnMulti = findViewById<Button>(R.id.btnMulti)
        btnMulti.setOnClickListener {
            var Num7 : Int = edtInput.text.toString().toInt()
            var Num8 : Int = edtInput2.text.toString().toInt()
            var MultiAns = Num7*Num8
            edtMainAnswer.text = String.format("$Num7"+"×"+"$Num8"+"="+"$MultiAns")
        }

        }
        }
}